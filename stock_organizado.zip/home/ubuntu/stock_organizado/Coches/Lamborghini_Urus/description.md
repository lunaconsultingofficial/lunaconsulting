## Lamborghini Urus

El Lamborghini Urus es el primer Super SUV del mundo, combinando la potencia y el rendimiento de un superdeportivo con la versatilidad y el espacio de un SUV. Su diseño audaz y agresivo, junto con su motor V8 biturbo, lo convierten en un vehículo inconfundible y emocionante de conducir. Ideal para quienes buscan una experiencia de lujo y adrenalina en cualquier terreno.

**Características destacadas:**
*   **Rendimiento de superdeportivo:** Motor V8 biturbo que ofrece una aceleración impresionante y una velocidad máxima emocionante.
*   **Diseño distintivo:** Líneas aerodinámicas y agresivas que reflejan la herencia de Lamborghini, destacando en cualquier entorno.
*   **Versatilidad diaria:** Espacio interior generoso y capacidad de carga, ideal para el uso diario y aventuras familiares.
*   **Tecnología avanzada:** Sistemas de asistencia al conductor y conectividad de última generación para una experiencia de conducción segura y placentera.

**Precio:** Contactar para negociar.

